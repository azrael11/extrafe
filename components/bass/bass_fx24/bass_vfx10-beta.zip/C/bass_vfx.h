/*==============================================================================
 BASS_VFX 1.0 - Copyright (c) 2008 (: JOBnik! :) [Arthur Aminov, ISRAEL]
                                                 [http://www.jobnik.org]

	  bugs/suggestions/questions:
	    forum  : http://www.un4seen.com/forum/?board=1
		         http://www.jobnik.org/smforum
	    e-mail : jobnik@jobnik.org
     --------------------------------------------------

 NOTE: This header will work only with BASS_VFX version 1.0
       Check www.un4seen.com or www.jobnik.org for any later versions.

 * Requires BASS (available @ www.un4seen.com)

  BASS_VFX is FREE OpenSource library!
  ------------------------------------
  * You can add, modify, update any code of/into this library as long and you 
    agree with below conditions!
  * No GPL/LGPL (or equal to this) code is allowed when you're adding,
    modifying any new functions/features.
  * You can use BASS_VFX in Commercial/Shareware products as long and you're
    giving PROPER CREDITS to the author of this library and any author that
    has modified/updated/added any feature to this library
    (see BASS_VFX.TXT for this information)!
  * License can be found in:
     LICENSE.TXT
	 http://www.jobnik.org/bass_vfx/license.txt

  DISCLAMER:
  ---------
  This software is provided "as is", without warranty of ANY KIND, either
  expressed or implied, including but not limited to the implied warranties of
  merchantability and/or fitness for a particular purpose. The author shall
  NOT be held liable for ANY damage to you, your computer, or to anyone or
  anything else, that may result from its use, or misuse. Basically, you use
  it at YOUR OWN RISK. 

  The above copyright notice and this license must appear in all source copies.

  Usage of BASS_VFX indicates that you agree to the above conditions.
==============================================================================*/

#ifndef BASS_VFX_H
#define BASS_VFX_H

#ifdef __cplusplus
  extern "C" {
#endif

#define BASS_VFXVERSION		0x100	// API version
#define BASS_VFXVERSIONTEXT	"1.0"

#ifndef BASS_VFXDEF
  #define BASS_VFXDEF(f) WINAPI f
#endif

//------------------------------------------------------------------------------
// vfx handle
//------------------------------------------------------------------------------
typedef DWORD HVFX;

//------------------------------------------------------------------------------
// bass_vfx version
//------------------------------------------------------------------------------
DWORD BASS_VFXDEF(BASS_VFX_GetVersion)();
//	RETURN : For example, 0x01020304 (hex), would be version 1.2.3.4

//------------------------------------------------------------------------------
//	V F X (Visual Effects)
//------------------------------------------------------------------------------

enum {
	BASS_VFX_SPECTRUM,
	BASS_VFX_SPECBANDS,
	BASS_VFX_SPEC3D,
	BASS_VFX_WAVEFORM
};

//------------------------------------------------------------------------------
// shared parameters for all visual effects
//------------------------------------------------------------------------------
typedef struct {
	HWND hWnd;						// window handle
	int  lWidth;					// window width
	int  lHeight;					// window height
	UINT uTimerDelay;				// timer delay
	UINT uTimerResolution;			// timer resolution
	int  lBkGrndColor;				// display back ground color
} BASS_VFXSHARED;

//------------------------------------------------------------------------------
// Spectrum
//------------------------------------------------------------------------------
#define BASS_VFX_SPECTRUM_SCALE_SQRT	0
#define BASS_VFX_SPECTRUM_SCALE_LINEAR	1

typedef struct {
	BASS_VFXSHARED shared;
	int  lScale;					// BASS_VFX_SPECTRUM_SCALE_xxx
	int  lFFTsize;					// 128/256/512/1024/2048/4096
	BOOL lCombineBins;				// combine multiple bins
} BASS_VFXSPECTRUM;

//------------------------------------------------------------------------------
// Specbands
//------------------------------------------------------------------------------
typedef struct {
	BASS_VFXSHARED shared;
	int  lBands;					// number of bands
	int  lFFTsize;					// 128/256/512/1024/2048/4096
} BASS_VFXSPECBANDS;

//------------------------------------------------------------------------------
// Spec3D
//------------------------------------------------------------------------------
typedef struct {
	BASS_VFXSHARED shared;
	int  lMarkerPos;				// marker position
	int  lFFTsize;					// 128/256/512/1024/2048/4096
	BOOL lCombineBins;				// combine multiple bins
} BASS_VFXSPEC3D;

//------------------------------------------------------------------------------
// Waveform
//------------------------------------------------------------------------------
typedef struct {
	BASS_VFXSHARED shared;
} BASS_VFXWAVEFORM;

//------------------------------------------------------------------------------
// functions
//------------------------------------------------------------------------------
HVFX BASS_VFXDEF(BASS_VFX_Set)(DWORD handle, HWND hWnd, int vfx);
BOOL BASS_VFXDEF(BASS_VFX_Remove)(DWORD handle, HVFX vfx);
BOOL BASS_VFXDEF(BASS_VFX_SetParameters)(HVFX handle, const void *params);
BOOL BASS_VFXDEF(BASS_VFX_GetParameters)(HVFX handle, void *params);
BOOL BASS_VFXDEF(BASS_VFX_Reset)(HVFX handle);

#ifdef __cplusplus
}
#endif

#endif
