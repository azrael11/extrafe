/*=====================================================================
 vfx.c/h/rc - Copyright (c) 2008 (: JOBnik! :) [Arthur Aminov, ISRAEL]
                                               [http://www.jobnik.org]
                                               [  jobnik@jobnik.org  ]
 BASS_VFX - Visual effects in Action
 * Imports: bass.lib, bass_vfx.lib
            kernel32.lib, user32.lib, comdlg32.lib gdi32.lib
=====================================================================*/

#include <windows.h>
#include <commctrl.h>
#include <stdio.h>
#include "bass.h"
#include "bass_vfx.h"
#include "vfx.h"

//=====================================================================
// global variables
//=====================================================================
HWND win = NULL;				// main dialog handle
HINSTANCE inst;

DWORD chan;						// channel handle
HVFX vfxSpectrum, vfxWaveform;	// vfx handles

OPENFILENAME ofn;
char path[MAX_PATH];

//=====================================================================
// macros
//=====================================================================
#define MESS(id, m, w, l) SendDlgItemMessage(win, id, m, (WPARAM)w, (LPARAM)l)
#define hWnd2Id(hwnd) GetDlgCtrlID((HWND)hwnd)
#define Id2hWnd(id) GetDlgItem(win, id);

//=====================================================================
// display error messages
//=====================================================================
void Error(const char *es)
{
	char mes[200];
	sprintf(mes, "%s\n\n(error code: %d)", es, BASS_ErrorGetCode());
	MessageBox(win, mes, "Error",MB_ICONEXCLAMATION);
}
//=====================================================================
// show the position in MM:SS format
//=====================================================================
void UpdatePositionLabel(void)
{
	char c[30];
	float totalsec = (float)MESS(IDC_POS,TBM_GETRANGEMAX, 0, 0);
	float posec = (float)MESS(IDC_POS,TBM_GETPOS, 0, 0);
	sprintf(c, "Playing position: %02d:%02d / %02d:%02d", (int)posec / 60, (int)posec % 60, (int)totalsec / 60, (int)totalsec % 60);
	MESS(IDC_SPOS, WM_SETTEXT, 0, c);
}
//=====================================================================
// get the file name from the file path
//=====================================================================
char *GetFileName(const char *fp)
{
	unsigned char slash_location;
	fp = strrev(fp);
	slash_location = strchr(fp, '\\') - fp;
	return (strrev(fp) + strlen(fp) - slash_location);
}
//=====================================================================
// main dialog function
//=====================================================================
BOOL CALLBACK dialogproc(HWND h,UINT m,WPARAM w, LPARAM l)
{
	DWORD p;
	char c[30];
	static int seeking = -1;

	switch (m) {
		case WM_CTLCOLORDLG:{
			static HBRUSH hbrBackground;
			return (long)hbrBackground;
		}
		case WM_CTLCOLORSTATIC:
			if(hWnd2Id(l) == IDC_VFXSPECTRUM || hWnd2Id(l) == IDC_VFXWAVEFORM){ 
				SelectObject((HDC)w, GetStockObject(PS_DASH));
				return (long)GetStockObject(BLACK_BRUSH);
			}
		case WM_COMMAND:
			switch (LOWORD(w)) {
				case ID_OPEN:
					{
						char file[MAX_PATH]="";
						ofn.lpstrFilter="playable files\0*.mo3;*.xm;*.mod;*.s3m;*.it;*.mtm;*.mp3;*.mp2;*.mp1;*.ogg;*.wav;*.aif\0All files\0*.*\0\0";
						ofn.lpstrFile=file;
						if (GetOpenFileName(&ofn)) {
							memcpy(path,file,ofn.nFileOffset);
							path[ofn.nFileOffset-1]=0;

							// free all stuff
							BASS_StreamFree(chan);

							// create stream channel
							chan = BASS_StreamCreateFile(FALSE, file, 0, 0, BASS_SAMPLE_LOOP);

							// create music channel
							if (!chan) chan = BASS_MusicLoad(FALSE, file, 0, 0, BASS_MUSIC_RAMP | BASS_MUSIC_PRESCAN | BASS_SAMPLE_LOOP, 0);

							if (!chan){
								// not a WAV/MP3 or MOD
								MESS(ID_OPEN,WM_SETTEXT,0,"click here to open a file && play it...");
								Error("Selected file couldn't be loaded!");
								break;
							}

							// update the position slider
							p = (DWORD)BASS_ChannelBytes2Seconds(chan, BASS_ChannelGetLength(chan, BASS_POS_BYTE));
							MESS(IDC_POS,TBM_SETRANGEMAX,0,p);
							MESS(IDC_POS,TBM_SETPOS,TRUE,0);

							// update the button to show the loaded file name
							MESS(ID_OPEN,WM_SETTEXT,0,GetFileName(file));

							// update the time view
							UpdatePositionLabel();

							// set vfx
							SendMessage(win,WM_COMMAND,IDC_CHKSPECTRUM,l);
							SendMessage(win,WM_COMMAND,IDC_CHKWAVEFORM,l);

							// set default fft size
							MESS(ID_CMBFFTSIZE, CB_SETCURSEL, 3, 0);

							// play
							BASS_ChannelPlay(chan,FALSE);
						}
					}
				return 1;

				case IDC_CHKSPECTRUM:
					if(MESS(IDC_CHKSPECTRUM,BM_GETCHECK,0,0))
					{
						// check if vfx is already displaying in that window
						BASS_VFXWAVEFORM wav;
						HWND hw=Id2hWnd(IDC_VFXSPECTRUM);
						BASS_VFX_GetParameters(vfxWaveform, &wav);
						if(wav.shared.hWnd == hw) hw = Id2hWnd(IDC_VFXWAVEFORM);
						// set vfx
						vfxSpectrum = BASS_VFX_Set(chan, hw, BASS_VFX_SPECTRUM);
					}
					else
						BASS_VFX_Remove(chan, vfxSpectrum);
				return 1;

				case IDC_CHKWAVEFORM:
					if(MESS(IDC_CHKWAVEFORM,BM_GETCHECK,0,0))
					{
						// check if vfx is already displaying in that window
						BASS_VFXSPECTRUM spc;
						HWND hw=Id2hWnd(IDC_VFXWAVEFORM);
						BASS_VFX_GetParameters(vfxSpectrum, &spc);
						if(spc.shared.hWnd == hw) hw = Id2hWnd(IDC_VFXSPECTRUM);
						// set vfx
						vfxWaveform = BASS_VFX_Set(chan, hw, BASS_VFX_WAVEFORM);
					}
					else
						BASS_VFX_Remove(chan, vfxWaveform);
				return 1;

				case ID_VFXSWITCH:
					{
						BASS_VFXSPECTRUM vfxSpc, tmp;
						BASS_VFXWAVEFORM vfxWav;

						if(!BASS_VFX_GetParameters(vfxSpectrum, &vfxSpc) ||
							!BASS_VFX_GetParameters(vfxWaveform, &vfxWav)) return 1;

						tmp = vfxSpc;
						vfxSpc.shared.hWnd = vfxWav.shared.hWnd;
						vfxSpc.shared.lWidth = vfxWav.shared.lWidth;
						vfxSpc.shared.lHeight = vfxWav.shared.lHeight;

						vfxWav.shared.hWnd = tmp.shared.hWnd;
						vfxWav.shared.lWidth = tmp.shared.lWidth;
						vfxWav.shared.lHeight = tmp.shared.lHeight;
						
						BASS_VFX_SetParameters(vfxSpectrum, &vfxSpc);
						BASS_VFX_SetParameters(vfxWaveform, &vfxWav);
					}
				return 1;

				case ID_CMBFFTSIZE: // change spectrum fft size
					if (HIWORD(w)==CBN_SELCHANGE) {
						BASS_VFXSPECTRUM vfxSpc;
						BASS_VFX_GetParameters(vfxSpectrum, &vfxSpc);
							GetDlgItemText(h, ID_CMBFFTSIZE, c, 4);
							vfxSpc.lFFTsize = atoi(c);
						BASS_VFX_SetParameters(vfxSpectrum, &vfxSpc);
					}
				return 1;
			}
			break;

		case WM_HSCROLL:
			if (hWnd2Id(l) == IDC_POS){
				// change the position
				seeking=MESS(IDC_POS,TBM_GETPOS,0,0);;
				if (LOWORD(w) == SB_ENDSCROLL) { // seek to new pos
					BASS_ChannelSetPosition(chan, (QWORD)BASS_ChannelSeconds2Bytes(chan, (double)seeking), BASS_POS_BYTE);
					seeking=-1;
				} 
				// update the time in seconds view
				UpdatePositionLabel();
			}
			return 1;

		case WM_TIMER:
			if (seeking==-1) { // not seeking - update pos scroller
				MESS(IDC_POS,TBM_SETPOS,1,(DWORD)BASS_ChannelBytes2Seconds(chan,BASS_ChannelGetPosition(chan,BASS_POS_BYTE)));

				// update the time in seconds view
				UpdatePositionLabel();
			}
			return 1;

		case WM_CLOSE:
			EndDialog(h, 0);
			return 1;
		break;

		case WM_INITDIALOG:
			win=h;
			GetCurrentDirectory(MAX_PATH,path);
			memset(&ofn,0,sizeof(ofn));
			ofn.lStructSize=sizeof(ofn);
			ofn.hwndOwner=h;
			ofn.hInstance=inst;
			ofn.nMaxFile=MAX_PATH;
			ofn.Flags=OFN_HIDEREADONLY|OFN_EXPLORER;

			// setup output - default device, 44100hz, stereo, 16 bits
			if (!BASS_Init(-1,44100,0,win,NULL)) {
				Error("Can't initialize device");
				DestroyWindow(win);
				return 1;
			}
			// set position slider
			MESS(IDC_POS,TBM_SETRANGEMAX,0,0);
			MESS(IDC_POS,TBM_SETPOS,TRUE,0);
			{
				// add items to fft size combobox
				int i;
				for (i=128;i<=4096;i*=2) MESS(ID_CMBFFTSIZE, CB_ADDSTRING, 0, itoa(i,c,10));
				// default 1024
				MESS(ID_CMBFFTSIZE, CB_SETCURSEL, 3, 0);
			}
			SetTimer(win,0,500,0); // timer to update the position
			return 1;
	}
	return 0;
}
//=====================================================================
// main
//=====================================================================
int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	inst = hInstance;

	// check the correct BASS was loaded
	if (HIWORD(BASS_GetVersion())!=BASSVERSION) {
		MessageBox(0,"An incorrect version of BASS.DLL was loaded (2.4 is required)","Incorrect BASS.DLL",MB_ICONERROR);
		return 1;
	}

	// check the correct BASS_VFX was loaded
	if (HIWORD(BASS_VFX_GetVersion())!=BASS_VFXVERSION) {
		MessageBox(0,"An incorrect version of BASS_VFX.DLL was loaded (1.0 is required)","Incorrect BASS_VFX.DLL",MB_ICONERROR);
		return 1;
	}

	DialogBox(inst,(char*)1000,0,&dialogproc);

	BASS_Free();

	return 0;
}
//=[EOF - vfx.c]=======================================================
