/*******************************************************************************
   BASS_VFX v1.0 Visual FX functions library
  -------------------------------------------
  � 2008 (: JOBnik! :) [Arthur Aminov, ISRAEL]
  http://www.jobnik.org

  An extension to the BASS Audio library
  � 1999-2008 Ian Luck
  http://www.un4seen.com

  -------------------------------------------
   Filename   : specbands.cpp
   Description: spectrum bands visual effect
  -------------------------------------------

  BASS_VFX is FREE OpenSource library!
  ------------------------------------
  * You can add, modify, update any code of/into this library as long and you 
    agree with below conditions!
  * No GPL/LGPL (or equal to this) code is allowed when you're adding,
    modifying any new functions/features.
  * You can use BASS_VFX in Commercial/Shareware products as long and you're
    giving PROPER CREDITS to the author of this library and any author that
    has modified/updated/added any feature to this library
    (see BASS_VFX.TXT for this information)!
  * License can be found in:
     LICENSE.TXT
	 http://www.jobnik.org/bass_vfx/license.txt

  DISCLAMER:
  ---------
  This software is provided "as is", without warranty of ANY KIND, either
  expressed or implied, including but not limited to the implied warranties of
  merchantability and/or fitness for a particular purpose. The author shall
  NOT be held liable for ANY damage to you, your computer, or to anyone or
  anything else, that may result from its use, or misuse. Basically, you use
  it at YOUR OWN RISK. 

  The above copyright notice and this license must appear in all source copies.

  Usage of BASS_VFX indicates that you agree to the above conditions.
*******************************************************************************/

//----------------------------------------------------------------------------------------------
// I N C L U D E
//----------------------------------------------------------------------------------------------
#include "../bass_vfx_std.h"

//----------------------------------------------------------------------------------------------
// GLOBAL Variables & Macros
//----------------------------------------------------------------------------------------------
// Specbands
typedef struct {
	int			bndBands;
	sharedVFX	svfx;
} BNDVFX;

//----------------------------------------------------------------------------------------------
// update the spectrum (logarithmic, acumulate & average bins) display
//----------------------------------------------------------------------------------------------

#pragma optimize("t",on) // speed optimizations

static void CALLBACK __VFX_UpdateSpecbands(UINT uTimerID, UINT uMsg, BNDVFX *bnd, DWORD dw1, DWORD dw2)
{
	int x, y;
	int b0 = 0;
	float *fft;

	BASS_ChannelLock(bnd->svfx.svfxHandle, TRUE);

	// get the FFT data
	fft = (float*)alloca(bnd->svfx.svfxSizeFFT * sizeof(float)); // allocate buffer for data
	BASS_ChannelGetData(bnd->svfx.svfxHandle, fft, bnd->svfx.svfxBASS_DATA_FFT);

	// clear display
	memset(bnd->svfx.svfxSpecBuf, bnd->svfx.svfxShared.lBkGrndColor, bnd->svfx.svfxShared.lWidth * bnd->svfx.svfxShared.lHeight);

	for (x = 0; x < bnd->bndBands; x++) {
		float sum = 0;
		int sc, b1 = pow(2, x * 10.0 / (bnd->bndBands - 1));
		if (b1 > bnd->svfx.svfxSizeFFT - 1) b1 = bnd->svfx.svfxSizeFFT - 1;
		if (b1 <= b0) b1 = b0 + 1; // make sure it uses at least 1 FFT bin
		sc = 10 + b1 - b0;
		for (;b0 < b1; b0++) sum += fft[1 + b0];
		y = (sqrt(sum / log10(sc)) * 1.7 * bnd->svfx.svfxShared.lHeight) - 4; // scale it
		if (y > bnd->svfx.svfxShared.lHeight) y = bnd->svfx.svfxShared.lHeight; // cap it
		while (--y >= 0)
			memset(bnd->svfx.svfxSpecBuf + y * bnd->svfx.svfxShared.lWidth + x * (bnd->svfx.svfxShared.lWidth / bnd->bndBands), 1 + (y * 127 / bnd->svfx.svfxShared.lHeight), bnd->svfx.svfxShared.lWidth / bnd->bndBands - 2); // draw bar
	}

	// update the display
	BitBlt(bnd->svfx.svfxDC, 0, 0, bnd->svfx.svfxShared.lWidth, bnd->svfx.svfxShared.lHeight, bnd->svfx.svfxSpecDC, 0, 0, SRCCOPY);

	BASS_ChannelLock(bnd->svfx.svfxHandle, FALSE);
}

#pragma optimize("",on) // restore optimizations

//----------------------------------------------------------------------------------------------
// remove chosen visual fx
//----------------------------------------------------------------------------------------------
static void WINAPI VFX_Free(void *inst)
{
	BNDVFX *bnd=(BNDVFX*)inst;
	sharedRemove(&bnd->svfx, bnd);
}
//----------------------------------------------------------------------------------------------
// get parameters
//----------------------------------------------------------------------------------------------
static BOOL WINAPI VFX_GetParameters(void *inst, void *param)
{
	BNDVFX *bndc=(BNDVFX*)inst;
	BASS_VFXSPECBANDS *bnd = (BASS_VFXSPECBANDS*)param;

	bnd->lBands = bndc->bndBands;
	bnd->lFFTsize = bndc->svfx.svfxSizeFFT;

	return sharedGetParams(&bnd->shared, &bndc->svfx);
}
//----------------------------------------------------------------------------------------------
// set parameters
//----------------------------------------------------------------------------------------------
static BOOL WINAPI VFX_SetParameters(void *inst, const void *param)
{
	BNDVFX *bndc=(BNDVFX*)inst;
	BASS_VFXSPECBANDS *bnd = (BASS_VFXSPECBANDS*)param;

	if (bnd->lBands < 1 || bnd->lFFTsize<128 || bnd->lFFTsize>4096)
		error(BASS_ERROR_ILLPARAM);

	bndc->bndBands = bnd->lBands;
	return sharedSetParams(&bndc->svfx, &bnd->shared, bnd->lFFTsize);
}
//----------------------------------------------------------------------------------------------
// reset VFX state/buffers
//----------------------------------------------------------------------------------------------
static BOOL WINAPI VFX_Reset(void *inst)
{
	BNDVFX *bndc=(BNDVFX*)inst;
	return sharedReset(&bndc->svfx);
}
//----------------------------------------------------------------------------------------------
// set chosen visual fx
//----------------------------------------------------------------------------------------------

// FX function table
static ADDON_FUNCTIONS_FX VFXfuncs={VFX_Free, VFX_SetParameters, VFX_GetParameters, VFX_Reset};

HVFX SetVFX_Specbands(DWORD chan, HWND hWnd, BASS_CHANNELINFO *info)
{
	BNDVFX *bnd=(BNDVFX*) malloc(sizeof(BNDVFX));
	memset(bnd, 0, sizeof(BNDVFX));

	bnd->bndBands = 28;
	return sharedSetVFX(&bnd->svfx, chan, hWnd, (LPTIMECALLBACK)&__VFX_UpdateSpecbands, bnd, &VFXfuncs);
}
//-[EOF - specbands.cpp]------------------------------------------------------------------------
