/*******************************************************************************
   BASS_VFX v1.0 Visual FX functions library
  -------------------------------------------
  � 2008 (: JOBnik! :) [Arthur Aminov, ISRAEL]
  http://www.jobnik.org

  An extension to the BASS Audio library
  � 1999-2008 Ian Luck
  http://www.un4seen.com

  -------------------------------------------
   Filename   : spec3d.cpp
   Description: 3d spectrum visual effect
  -------------------------------------------

  BASS_VFX is FREE OpenSource library!
  ------------------------------------
  * You can add, modify, update any code of/into this library as long and you 
    agree with below conditions!
  * No GPL/LGPL (or equal to this) code is allowed when you're adding,
    modifying any new functions/features.
  * You can use BASS_VFX in Commercial/Shareware products as long and you're
    giving PROPER CREDITS to the author of this library and any author that
    has modified/updated/added any feature to this library
    (see BASS_VFX.TXT for this information)!
  * License can be found in:
     LICENSE.TXT
	 http://www.jobnik.org/bass_vfx/license.txt

  DISCLAMER:
  ---------
  This software is provided "as is", without warranty of ANY KIND, either
  expressed or implied, including but not limited to the implied warranties of
  merchantability and/or fitness for a particular purpose. The author shall
  NOT be held liable for ANY damage to you, your computer, or to anyone or
  anything else, that may result from its use, or misuse. Basically, you use
  it at YOUR OWN RISK. 

  The above copyright notice and this license must appear in all source copies.

  Usage of BASS_VFX indicates that you agree to the above conditions.
*******************************************************************************/

//----------------------------------------------------------------------------------------------
// I N C L U D E
//----------------------------------------------------------------------------------------------
#include "../bass_vfx_std.h"

//----------------------------------------------------------------------------------------------
// GLOBAL Variables & Macros
//----------------------------------------------------------------------------------------------
// Spec3D
typedef struct {
	int			s3dMarkerPos;	// marker pos
	BOOL		s3dCombineBins;
	sharedVFX	svfx;
} S3DVFX;

//----------------------------------------------------------------------------------------------
// update the spectrum (3D) display
//----------------------------------------------------------------------------------------------

#pragma optimize("t",on) // speed optimizations

static void CALLBACK __VFX_UpdateSpec3D(UINT uTimerID, UINT uMsg, S3DVFX *s3d, DWORD dw1, DWORD dw2)
{
	int x, y;
	int x2 = 0; // current bin marker
	float *fft;

	BASS_ChannelLock(s3d->svfx.svfxHandle, TRUE);

	// get the FFT data
	fft = (float*)alloca(s3d->svfx.svfxSizeFFT * sizeof(float)); // allocate buffer for data
	BASS_ChannelGetData(s3d->svfx.svfxHandle, fft, s3d->svfx.svfxBASS_DATA_FFT);

	for (x = 0; x < s3d->svfx.svfxShared.lHeight; x++) {
		if(s3d->s3dCombineBins) {
			float y2 = fft[1 + x2];
			while (x2 < (x + 1) * (s3d->svfx.svfxSizeFFT - 1) / s3d->svfx.svfxShared.lHeight) { // combine multiple bins if necessary...
				x2++;
				if (y2 < fft[1 + x2]) y2 = fft[1 + x2];
			}
			y = sqrt(y2) * 3 * 127; // scale it (sqrt to make low values more visible)
		} else
			y = sqrt(fft[x + 1]) * 3 * 127; // scale it (sqrt to make low values more visible)

		if (y > 127) y = 127; // cap it
		s3d->svfx.svfxSpecBuf[x * s3d->svfx.svfxShared.lWidth + s3d->s3dMarkerPos] = 128 + y; // plot it
	}
	// move marker onto next position
	s3d->s3dMarkerPos = (s3d->s3dMarkerPos + 1) % s3d->svfx.svfxShared.lWidth;
	for (x = 0; x < s3d->svfx.svfxShared.lHeight; x++) s3d->svfx.svfxSpecBuf[x * s3d->svfx.svfxShared.lWidth + s3d->s3dMarkerPos] = 255;

	// update the display
	BitBlt(s3d->svfx.svfxDC, 0, 0, s3d->svfx.svfxShared.lWidth, s3d->svfx.svfxShared.lHeight, s3d->svfx.svfxSpecDC, 0, 0, SRCCOPY);

	BASS_ChannelLock(s3d->svfx.svfxHandle, FALSE);
}

#pragma optimize("",on) // restore optimizations

//----------------------------------------------------------------------------------------------
// remove chosen visual fx
//----------------------------------------------------------------------------------------------
static void WINAPI VFX_Free(void *inst)
{
	S3DVFX *s3d=(S3DVFX*)inst;
	sharedRemove(&s3d->svfx, s3d);
}
//----------------------------------------------------------------------------------------------
// get parameters
//----------------------------------------------------------------------------------------------
static BOOL WINAPI VFX_GetParameters(void *inst, void *param)
{
	S3DVFX *s3dc=(S3DVFX*)inst;
	BASS_VFXSPEC3D *s3d = (BASS_VFXSPEC3D*)param;

	s3d->lMarkerPos = s3dc->s3dMarkerPos;
	s3d->lFFTsize = s3dc->svfx.svfxSizeFFT;
	s3d->lCombineBins = s3dc->s3dCombineBins;

	return sharedGetParams(&s3d->shared, &s3dc->svfx);
}
//----------------------------------------------------------------------------------------------
// set parameters
//----------------------------------------------------------------------------------------------
static BOOL WINAPI VFX_SetParameters(void *inst, const void *param)
{
	S3DVFX *s3dc=(S3DVFX*)inst;
	BASS_VFXSPEC3D *s3d = (BASS_VFXSPEC3D*)param;

	if(s3d->lFFTsize < 128 || s3d->lFFTsize > 4096 || s3d->lMarkerPos < 0)
		error(BASS_ERROR_ILLPARAM);

	s3dc->s3dMarkerPos = s3d->lMarkerPos;
	s3dc->s3dCombineBins = s3d->lCombineBins;

	return sharedSetParams(&s3dc->svfx, &s3d->shared, s3d->lFFTsize);
}
//----------------------------------------------------------------------------------------------
// reset VFX state/buffers
//----------------------------------------------------------------------------------------------
static BOOL WINAPI VFX_Reset(void *inst)
{
	S3DVFX *s3dc=(S3DVFX*)inst;
	return sharedReset(&s3dc->svfx);
}
//----------------------------------------------------------------------------------------------
// set chosen visual fx
//----------------------------------------------------------------------------------------------

// FX function table
static ADDON_FUNCTIONS_FX VFXfuncs={VFX_Free, VFX_SetParameters, VFX_GetParameters, VFX_Reset};

HVFX SetVFX_Spec3D(DWORD chan, HWND hWnd, BASS_CHANNELINFO *info)
{
	S3DVFX *s3d=(S3DVFX*) malloc(sizeof(S3DVFX));
	memset(s3d, 0, sizeof(S3DVFX));

	//s3d->s3dMarkerPos = 0;
	return sharedSetVFX(&s3d->svfx, chan, hWnd, (LPTIMECALLBACK)&__VFX_UpdateSpec3D, s3d, &VFXfuncs);
}
//-[ EOF - spec3d.cpp ]-------------------------------------------------------------------------
