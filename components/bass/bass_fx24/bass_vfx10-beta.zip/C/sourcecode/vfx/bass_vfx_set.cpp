/*******************************************************************************
   BASS_VFX v1.0 Visual FX functions library
  -------------------------------------------
  � 2008 (: JOBnik! :) [Arthur Aminov, ISRAEL]
  http://www.jobnik.org

  An extension to the BASS Audio library
  � 1999-2008 Ian Luck
  http://www.un4seen.com

  -------------------------------------------
   Filename   : bass_vfx_set.cpp
   Description: main functions
  -------------------------------------------

  BASS_VFX is FREE OpenSource library!
  ------------------------------------
  * You can add, modify, update any code of/into this library as long and you 
    agree with below conditions!
  * No GPL/LGPL (or equal to this) code is allowed when you're adding,
    modifying any new functions/features.
  * You can use BASS_VFX in Commercial/Shareware products as long and you're
    giving PROPER CREDITS to the author of this library and any author that
    has modified/updated/added any feature to this library
    (see BASS_VFX.TXT for this information)!
  * License can be found in:
     LICENSE.TXT
	 http://www.jobnik.org/bass_vfx/license.txt

  DISCLAMER:
  ---------
  This software is provided "as is", without warranty of ANY KIND, either
  expressed or implied, including but not limited to the implied warranties of
  merchantability and/or fitness for a particular purpose. The author shall
  NOT be held liable for ANY damage to you, your computer, or to anyone or
  anything else, that may result from its use, or misuse. Basically, you use
  it at YOUR OWN RISK. 

  The above copyright notice and this license must appear in all source copies.

  Usage of BASS_VFX indicates that you agree to the above conditions.
*******************************************************************************/

//----------------------------------------------------------------------------------------------
// I N C L U D E
//----------------------------------------------------------------------------------------------
#include "../bass_vfx_std.h"
#include "spectrum.h"
#include "specbands.h"
#include "spec3d.h"
#include "waveform.h"

//----------------------------------------------------------------------------------------------
// set chosen visual fx
// VFX plugin function. return VFX handle, 0=unrecognised VFX or error
//----------------------------------------------------------------------------------------------
HVFX WINAPI BASS_VFX_Set(DWORD handle, HWND hWnd, int vfx)
{
	BASS_CHANNELINFO info;
	if(!BASS_ChannelGetInfo(handle, &info)) return 0;	// invalid handle

	switch (vfx) {
		case BASS_VFX_SPECTRUM: return SetVFX_Spectrum(handle, hWnd, &info);
		case BASS_VFX_SPECBANDS: return SetVFX_Specbands(handle, hWnd, &info);
		case BASS_VFX_SPEC3D: return SetVFX_Spec3D(handle, hWnd, &info);
		case BASS_VFX_WAVEFORM: return SetVFX_Waveform(handle, hWnd, &info);
	}
	error(BASS_ERROR_ILLPARAM);
}
//----------------------------------------------------------------------------------------------
// remove chosen visual fx
//----------------------------------------------------------------------------------------------
BOOL WINAPI BASS_VFX_Remove(DWORD handle, HVFX vfx)
{
	return BASS_ChannelRemoveFX(handle, vfx);
}
//----------------------------------------------------------------------------------------------
// get parameters
//----------------------------------------------------------------------------------------------
BOOL WINAPI BASS_VFX_GetParameters(HVFX handle, void *params)
{
	return BASS_FXGetParameters(handle, params);
}
//----------------------------------------------------------------------------------------------
// set parameters
//----------------------------------------------------------------------------------------------
BOOL WINAPI BASS_VFX_SetParameters(HVFX handle, const void *params)
{
	return BASS_FXSetParameters(handle, params);
}
//----------------------------------------------------------------------------------------------
// reset parameters
//----------------------------------------------------------------------------------------------
BOOL WINAPI BASS_VFX_Reset(HVFX handle)
{
	return BASS_FXReset(handle);
}
//-[EOF - bass_vfx_set.cpp ]--------------------------------------------------------------------
