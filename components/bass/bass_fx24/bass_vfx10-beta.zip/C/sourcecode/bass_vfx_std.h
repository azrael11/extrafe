/*******************************************************************************
   BASS_VFX v1.0 Visual FX functions library
  -------------------------------------------
  � 2008 (: JOBnik! :) [Arthur Aminov, ISRAEL]
  http://www.jobnik.org

  An extension to the BASS Audio library
  � 1999-2008 Ian Luck
  http://www.un4seen.com

  -------------------------------------------
   Filename   : bass_vfx_std.h
  -------------------------------------------

  BASS_VFX is FREE OpenSource library!
  ------------------------------------
  * You can add, modify, update any code of/into this library as long and you 
    agree with below conditions!
  * No GPL/LGPL (or equal to this) code is allowed when you're adding,
    modifying any new functions/features.
  * You can use BASS_VFX in Commercial/Shareware products as long and you're
    giving PROPER CREDITS to the author of this library and any author that
    has modified/updated/added any feature to this library
    (see BASS_VFX.TXT for this information)!
  * License can be found in:
     LICENSE.TXT
	 http://www.jobnik.org/bass_vfx/license.txt

  DISCLAMER:
  ---------
  This software is provided "as is", without warranty of ANY KIND, either
  expressed or implied, including but not limited to the implied warranties of
  merchantability and/or fitness for a particular purpose. The author shall
  NOT be held liable for ANY damage to you, your computer, or to anyone or
  anything else, that may result from its use, or misuse. Basically, you use
  it at YOUR OWN RISK. 

  The above copyright notice and this license must appear in all source copies.

  Usage of BASS_VFX indicates that you agree to the above conditions.
*******************************************************************************/

//----------------------------------------------------------------------------------------------
// I N C L U D E
//----------------------------------------------------------------------------------------------
#if _MSC_VER > 1000
	#pragma once
#endif

#define WIN32_LEAN_AND_MEAN				// Exclude rarely-used stuff from Windows headers
#define TIME_KILL_SYNCHRONOUS 0x0100	// Passing this flag should prevent an event from occurring after the timeKillEvent() function is called.

#include <windows.h>
#include <Mmsystem.h>
#include <malloc.h>
#include <math.h>

#ifdef _DEBUG 
	#include <crtdbg.h> 
#endif 

#include "bass.h"
#include "bass-addon.h"
#include "bass_vfx.h"
//----------------------------------------------------------------------------------------------
// SetError macros
//----------------------------------------------------------------------------------------------
#define noerror() return (bassfunc->SetError(BASS_OK),TRUE)
#define noerrorn(n) return (bassfunc->SetError(BASS_OK),n)
#define error(n) return (bassfunc->SetError(n),FALSE) // error = 0/NULL
#define errorn(n) return (bassfunc->SetError(n),-1) // error = -1
//----------------------------------------------------------------------------------------------
// shared struct
//----------------------------------------------------------------------------------------------
typedef struct {
	BASS_VFXSHARED svfxShared;		// shared: hWnd, height, width...

	// display
	HDC     svfxSpecDC;
	HBITMAP svfxSpecBMP;
	BYTE    *svfxSpecBuf;
	HDC		svfxDC;					// DC display

	// channel
	DWORD				svfxHandle;	// channel handle
	BASS_CHANNELINFO	svfxInfo;	// channel info

	// fft
	int		svfxSizeFFT;			// 128/256/512/1024/2048/4096
	DWORD	svfxBASS_DATA_FFT;		// BASS_DATA_FFT256..BASS_DATA_FFT8192

	// timer
	MMRESULT		svfxHTimer;		// timer handle
	LPTIMECALLBACK	svfxTimerLPTC;	// callback function
	DWORD			svfxTimerUser;
} sharedVFX;
//----------------------------------------------------------------------------------------------
// shared functions
//----------------------------------------------------------------------------------------------
void sharedRemove(sharedVFX *svfx, void *inst);
BOOL sharedReset(sharedVFX *svfx);
BOOL sharedGetParams(BASS_VFXSHARED *shared, const sharedVFX *svfx);
BOOL sharedSetParams(sharedVFX *svfx, const BASS_VFXSHARED *shared, int fftSize);
HVFX sharedSetVFX(sharedVFX *svfx, DWORD chan, HWND hWnd, LPTIMECALLBACK timerLPTC, void *inst, const ADDON_FUNCTIONS_FX *funcs);

void setupBitmap(sharedVFX *svfx);
long getWindowWidth(HWND hWnd);
long getWindowHeight(HWND hWnd);
//-[EOF - bass_vfx_std.h]-----------------------------------------------------------------------
