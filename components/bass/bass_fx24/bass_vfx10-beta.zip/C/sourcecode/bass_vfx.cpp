/*******************************************************************************
   BASS_VFX v1.0 Visual FX functions library
  -------------------------------------------
  � 2008 (: JOBnik! :) [Arthur Aminov, ISRAEL]
  http://www.jobnik.org

  An extension to the BASS Audio library
  � 1999-2008 Ian Luck
  http://www.un4seen.com

  -------------------------------------------
   Filename   : bass_vfx.cpp
   Description: main dll functions
  -------------------------------------------

  BASS_VFX is FREE OpenSource library!
  ------------------------------------
  * You can add, modify, update any code of/into this library as long and you 
    agree with below conditions!
  * No GPL/LGPL (or equal to this) code is allowed when you're adding,
    modifying any new functions/features.
  * You can use BASS_VFX in Commercial/Shareware products as long and you're
    giving PROPER CREDITS to the author of this library and any author that
    has modified/updated/added any feature to this library
    (see BASS_VFX.TXT for this information)!
  * License can be found in:
     LICENSE.TXT
	 http://www.jobnik.org/bass_vfx/license.txt

  DISCLAMER:
  ---------
  This software is provided "as is", without warranty of ANY KIND, either
  expressed or implied, including but not limited to the implied warranties of
  merchantability and/or fitness for a particular purpose. The author shall
  NOT be held liable for ANY damage to you, your computer, or to anyone or
  anything else, that may result from its use, or misuse. Basically, you use
  it at YOUR OWN RISK. 

  The above copyright notice and this license must appear in all source copies.

  Usage of BASS_VFX indicates that you agree to the above conditions.
*******************************************************************************/

//----------------------------------------------------------------------------------------------
// I N C L U D E
//----------------------------------------------------------------------------------------------
#include "bass_vfx_std.h"

//----------------------------------------------------------------------------------------------
// get BASS_VFX version
//----------------------------------------------------------------------------------------------
DWORD WINAPI BASS_VFX_GetVersion(void)
{
	return 0x01000000;	// 1.0.0.0 (01 = 1 . 00 = 0 . 00 = 0 . 00 = 0)
}
//----------------------------------------------------------------------------------------------
// main dll function
//----------------------------------------------------------------------------------------------
BOOL WINAPI DllMain(HANDLE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
	#ifdef _DEBUG 
		_CrtSetReportMode( _CRT_WARN, _CRTDBG_MODE_DEBUG ); 
		_CrtSetReportMode( _CRT_ERROR, _CRTDBG_MODE_DEBUG ); 
		_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF 
		|_CRTDBG_CHECK_ALWAYS_DF 
		|_CRTDBG_LEAK_CHECK_DF); 
	#endif

    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
			DisableThreadLibraryCalls((HINSTANCE)hModule);
			if (HIWORD(BASS_GetVersion())!=BASSVERSION) {
					MessageBox(0,"Incorrect BASS.DLL version (2.4 is required)","BASS_VFX",MB_ICONERROR);
					return FALSE;
			}
    }
    return TRUE;
}
//-[EOF - bass_vfx.cpp]-------------------------------------------------------------------------
